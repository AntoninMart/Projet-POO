#include "pch.h"
#include "Map.h"

System::String^ compMappage::Map::Select(void)
{
	
	return "SELECT Client.code_client, Personne.nom_personne, Personne.prenom_personne, Client.date_naissance, Client.numero_service_client, Client.activite_client FROM Client INNER JOIN Personne ON Personne.idPersonne = Client.idPersonne ;";
}
System::String^ compMappage::Map::Insert(void)
{
	return "INSERT INTO Personne (nom, prenom) VALUES('" + this->nom + "','" + this->prenom + "'); ";
}
System::String^ compMappage::Map::Delete(void)
{
	return "DELETE FROM Personne WHERE nom = '" + this->nom + "', prenom = '" + this->prenom + "';";
}
System::String^ compMappage::Map::Update(void)
{
	return "";
}
void compMappage::Map::setId(int Id)
{
	this->Id = Id;
}
void compMappage::Map::setNom(System::String^ nom)
{
	this->nom = nom;
}
void compMappage::Map::setPrenom(System::String^ prenom)
{
	this->prenom = prenom;
}
int compMappage::Map::getId(void) { return this->Id; }
System::String^ compMappage::Map::getNom(void) { return this->nom; }
System::String^ compMappage::Map::getPrenom(void) { return this->prenom; }