#pragma once


ref class Personne
{
public:
	int codeClient;
	System::String^ nom;
	System::String^ prenom;
	System::DateTime^ dateAnniv;
	System::String^ numService;
	System::Boolean^ activiteClient;
};