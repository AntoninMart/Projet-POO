#include "pch.h"

using namespace System;

int main(array<System::String ^> ^args)
{
    return 0;
}
